import java.util.Scanner;
import java.util.Scanner.*;

public class ChocoCake {

	public static void main(String[] args) {

		Scanner CakeItems = new Scanner(System.in);

		double milk, cocoa, sugar;
		int No;

		System.out
				.println("Please enter the amount of items needed for one person");

		System.out.println("Quantity of MILK required for one person = ");
		milk = CakeItems.nextDouble();

		System.out.println("Quantity of COCOA required for one person = ");
		cocoa = CakeItems.nextDouble();

		System.out.println("Quantity of SUGAR required for one person = ");
		sugar = CakeItems.nextDouble();

		System.out
				.println("Please enter the no. of persons eating Chocolate Cake : ");
		No = CakeItems.nextInt();

		System.out.println("Your shopping list = ");
		double TotalMilk = (milk * No);
		double TotalCocoa = (cocoa * No);
		double TotalSugar = (sugar * No);

		System.out.println(TotalMilk + "Litres of Milk");
		System.out.println(TotalCocoa + "kgs of Cocoa");
		System.out.println(TotalSugar + "kgs of Sugar");

	}

}
